import React from 'react'

const Header = () => {
  return (
    <div>
      <br />
      <h1>Estados</h1>
    </div>
  )
}

export default Header
