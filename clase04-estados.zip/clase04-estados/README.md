componente -> es una funcion que si o si me debe retornar html o jsx(html+js)

useState -> hook (gancho o engancharse) -> funcion especial que sirve para solucionar determinado problema 